import axios from "axios"
import { useState } from "react"
import { useEffect } from "react"
import { Link } from "react-router-dom"
const Salary=()=>{
    const [data,setData]=useState([])
    const getData=()=>{
        axios.get(`https://localhost:7211/api/Salary`).then((res)=>{
            setData(res.data)
        }).catch((e)=>{
            console.log(e)
        })
    }
    useEffect(()=>{
        getData()
    },[data])
    const logoutStyle = {
      position: 'absolute',
      top: '15px',
      right: '20px',
      textDecoration: 'none',
      color: 'white',
      fontWeight: 'bold',
  };
    return(
         <div className="container" style={{marginTop:'50px'}}>
          <Link to="/" style={logoutStyle}>Logout</Link>

     <center><h2>Employee Salary Data</h2></center> 
      <table className="table table-bordered" style={{marginTop:'50px'}}>
      <thead className='thead-dark' style={{borderRadius:'5px',color:'white'}}>
          <tr>
            <th>S.No</th>
            <th>Salary Id</th>
            <th>Employee Id</th>
            <th>Monthly</th>
            <th>Yearly</th>
            <th>Basic Salary</th>
            <th>Allowances</th>
            <th>Deductions</th>
            <th>Net Salary</th>
            {/* Add more columns if needed */}
          </tr>
        </thead>
        <tbody>
          {/* {departments.filter(department => department.Id.toLowerCase().includes(searchTerm.toLowerCase()))} */}
          {
          data.map((e,i) => (
            <tr key={i}>
              <td>{i+1}</td>
              <td>{e.salaryId}</td>
              <td>{e.employeeId}</td>
              <td>{e.month}</td>
              <td>{e.year}</td>
              <td>{e.basicSalary}</td>
              <td>{e.allowances}</td>
              <td>{e.deductions}</td>
              <td><b>{e.netSalary}</b></td>
            </tr>
          ))  
          }
        </tbody>
      </table>
    </div>
        
    )
}
export default Salary