import React, { useState } from 'react';
import axios from 'axios';
import { Form, Button } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';

const EmployeeForm = () => {
    const navigate = useNavigate();

  const [employee, setEmployee] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    address: '',
    joinDate: '',
    departmentId: '',
    password: ''
  });

  const handleChange = e => {
    setEmployee({ ...employee, [e.target.name]: e.target.value });
  };

  const handleSubmit = async(e) => {
    e.preventDefault();
    try {
      const response = await axios.get('https://localhost:7211/api/Employee');
      const employees = response.data;
      const emailExists = employees.some(emp => emp.email === employee.email);

      if (emailExists) {
        window.alert('Email already registered!');
      } else {
        const joinDate = new Date(employee.joinDate);
        const dept = parseInt(employee.departmentId);
        const updatedEmployee = { ...employee, joinDate, departmentId: dept };

        await axios.post('https://localhost:7211/api/Employee', updatedEmployee);
        window.alert('Registration Successful ! Please Login');
        navigate('/');

      }
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div className='d-flex justify-content-center align-items-center vh-100' style={{'marginTop':'70px'}}>
      <div className='p-3 rounded w-50 border' style={{'backgroundColor':'white'}}>
        <h4>Employee Registration</h4>
        <Form onSubmit={handleSubmit}>
          <Form.Group controlId="formFirstName">
            <Form.Label>First Name</Form.Label>
            <Form.Control type="text" name="firstName" onChange={handleChange} />
          </Form.Group>

          <Form.Group controlId="formLastName">
            <Form.Label>Last Name</Form.Label>
            <Form.Control type="text" name="lastName" onChange={handleChange} />
          </Form.Group>

          <Form.Group controlId="formEmail">
            <Form.Label>Email</Form.Label>
            <Form.Control type="email" name="email" onChange={handleChange} />
          </Form.Group>

          <Form.Group controlId="formPhone">
            <Form.Label>Phone</Form.Label>
            <Form.Control type="tel" name="phone" onChange={handleChange} />
          </Form.Group>

          <Form.Group controlId="formAddress">
            <Form.Label>Address</Form.Label>
            <Form.Control type="text" name="address" onChange={handleChange} />
          </Form.Group>

          <Form.Group controlId="formJoinDate">
            <Form.Label>Join Date</Form.Label>
            <Form.Control type="date" name="joinDate" onChange={handleChange} />
          </Form.Group>

          <Form.Group controlId="formDepartmentId">
            <Form.Label>Department ID</Form.Label>
            <Form.Control type="number" name="departmentId" onChange={handleChange} />
          </Form.Group>

          <Form.Group controlId="formPassword" >
            <Form.Label>Password</Form.Label>
            <Form.Control type="password" name="password" onChange={handleChange} />
          </Form.Group>

          <Button variant="dark" type="submit" style={{'marginTop':"10px"}}>
            Submit
          </Button>
        </Form>
    </div>
   
    </div>


  );
};

export default EmployeeForm;
