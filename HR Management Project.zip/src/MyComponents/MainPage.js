// MainPage.js
import React from 'react';
import { Link } from 'react-router-dom';

const MainPage = () => {

    const iconStyle = {
        width: '200px', // Fixed width
        height: '200px', // Square shape
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        margin: '0 10px', // Adjust margin as needed
      };
    
      const textStyle = {
        textAlign: 'center',
        color:'black',
        fontWeight : 'bold',
        fontSize : '20px',
        marginTop: '5px', // Adjust as needed
      };
      const logoutStyle = {
        position: 'absolute',
        top: '15px',
        right: '20px',
        textDecoration: 'none',
        color: 'white',
        fontWeight: 'bold',
    };
  return (
<div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh',backgroundColor:'#dee0e3' }}>
<Link to="/" style={logoutStyle}>Logout</Link>
      <Link to="/department" style={{ textDecoration: 'none' }}>
        <div style={iconStyle}>
          <img src={process.env.PUBLIC_URL + '/images/dept.png'} alt="Departments" style={{ width: '100%', height: 'auto' }} />
          <div style={textStyle}>Departments</div>
        </div>
      </Link>

      <Link to="/leaverequest" style={{ textDecoration: 'none' }}>
        <div style={iconStyle}>
          <img src={process.env.PUBLIC_URL + '/images/leaverequest.png'} alt="LeaveRequest" style={{ width: '100%', height: 'auto' }} />
          <div style={textStyle}>LeaveRequests</div>
        </div>
      </Link>

      <Link to="/employee" style={{ textDecoration: 'none' }}>
        <div style={iconStyle}>
          <img src={process.env.PUBLIC_URL + '/images/emp.png'} alt="Employees" style={{ width: '100%', height: 'auto' }} />
          <div style={textStyle}>Employees</div>
        </div>
      </Link>
      
      <Link to="/Attendance" style={{ textDecoration: 'none' }}>
        <div style={iconStyle}>
          <img src={process.env.PUBLIC_URL + '/images/Attendance.png'} alt="Attendance" style={{ width: '100%', height: 'auto' }} />
          <div style={textStyle}>Attendance</div>
        </div>
      </Link>

      <Link to="/Salary" style={{ textDecoration: 'none' }}>
        <div style={iconStyle}>
          <img src={process.env.PUBLIC_URL + '/images/Salary.png'} alt="Salary" style={{ width: '100%', height: 'auto' }} />
          <div style={textStyle}>Salary</div>
        </div>
      </Link>

    </div>
  );
};

export default MainPage;