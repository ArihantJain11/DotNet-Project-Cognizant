import { useEffect, useState } from "react"
import { useLocation } from "react-router-dom"
import axios from "axios"
import { useParams } from 'react-router-dom';
import { Link } from "react-router-dom";


const PastLeave=()=>{
  const location = useLocation();
  const { employeeId } = useParams();
  console.log(employeeId); // Check if the employeeId is correctly extracted

  const [leave, setLeave] = useState([]);

  const getLeave = () => {
    axios.get(`https://localhost:7211/api/LeaveRequest`)
      .then((res) => {
        // Filter leave requests with the correct employeeId
       
        const filteredLeave = res.data.filter((request) => request.employeeId === parseInt(employeeId));
        setLeave(filteredLeave);
      })
      .catch((e) => {
        console.log(e);
      });
  };



  const handleDelete = (e, id) => {
    e.preventDefault();
    axios.delete(`https://localhost:7211/api/LeaveRequest/${id}`)
      .then((res) => {
        alert("Leave request Deleted successfully");
        window.location.reload();
      })
      .catch((e) => {
        console.log(e);
      });
  };
    useEffect(()=>{
        getLeave()
    },[])
    const logoutStyle = {
      position: 'absolute',
      top: '15px',
      right: '20px',
      textDecoration: 'none',
      color: 'white',
      fontWeight: 'bold',
  };
return(
  <div className="container" style={{marginTop:'50px',backgroundColor:'#dee0e3'}}>
          <Link to="/" style={logoutStyle}>Logout</Link>

  <center><h2>Past Leave</h2></center> 
      <table className="table table-bordered" style={{marginTop:'50px'}}>
      <thead className='thead-dark' style={{borderRadius:'5px',backgroundColor:'black',color:'white'}}>
          <tr>
            <th>S.No</th>
            <th>Request Id</th>
            <th>Start Date</th>
            <th>End Date</th>
            <th>Leave Type</th>
            <th>Status</th>
            <th>Action</th>
            {/* Add more columns if needed */}
          </tr>
        </thead>
        <tbody>
          
          {
          leave.map((emp,i) => (
            <tr key={i}>
              <td>{i+1}</td>
              <td>{emp.leaveRequestId}</td>
              <td>{emp.leaveStartDate.substring(0,10)}</td>
              <td>{emp.leaveEndDate.substring(0,10)}</td>
              <td>{emp.leaveType}</td>
              <td><b>{emp.status}</b></td>
              <td>  <button type='button' className='btn btn-dark ' onClick={(e) => handleDelete(e, emp.leaveRequestId)}>Delete</button>
</td>
            </tr>
          ))  
          }
        </tbody>
      </table>
    </div>
    
)
}
export default PastLeave