import React, { useState } from 'react';
import './style.css';
import axios from 'axios';
import { Link, useNavigate } from 'react-router-dom';

const LoginPage = () => {
  const [values, setValues] = useState({
    email: '',
    password: ''
  });

  const navigate = useNavigate();

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (values.email === 'admin@gmail.com' && values.password === 'admin') {
      navigate('/main');
    } else {
      try {
        // Fetch employee data from the backend API
        const response = await axios.get('https://localhost:7211/api/employee');
        const employees = response.data; // Assuming the API response contains an array of employees
  
        // Find the employee with the entered email
        const user = employees.find((emp) => emp.email === values.email);
  
        if (user && user.password === values.password) {
          // Credentials verified, navigate to /email
          navigate(`/employee/${user.email}`, { state: { employee: user } });

        } else {
          // Incorrect credentials, show an error message
          alert('Incorrect email or password');
          // You can set an error state here to display the error message to the user
        }
      } catch (error) {
        console.error('Error fetching employee data:', error);
        // Handle the error (e.g., show a generic error message)
      }
    
      
    }
  };

  return (
    <div className='d-flex justify-content-center align-items-center vh-100 LoginPage'>
      <div className='p-3 rounded w-25 border loginForm' style={{ backgroundColor: 'white' }}>
        <center><h2>Login</h2></center>
        <form onSubmit={handleSubmit}>
          <div className='mb-3'>
            <label htmlFor="email"><strong>Email:</strong></label>
            <input
              type="email"
              name='email'
              autoComplete='off'
              placeholder='Enter Email'
              value={values.email}
              onChange={(e) => setValues({ ...values, email: e.target.value })}
              className='form-control rounded-0' required
            />
          </div>
          <div className='mb-3'>
            <label htmlFor="password"><strong>Password:</strong></label>
            <input
              type="password"
              name='password'
              placeholder='Enter Password'
              value={values.password}
              onChange={(e) => setValues({ ...values, password: e.target.value })}
              className='form-control rounded-0' required
            />
          </div>
          <button type="submit" className='btn btn-dark w-100 rounded-0 mb-2'>Log in</button>
          <p>Not Registered ?<Link to='/signup'> Click Here</Link></p>
        </form>
      </div>
    </div>
  );
}

export default LoginPage;