import axios from "axios"
import { useEffect, useState } from "react"
import { Link } from "react-router-dom"
const Attendance=()=>{
    const [data,setData]=useState([])
    const getData=()=>{
        axios.get(`https://localhost:7211/api/Attendance`).then((res)=>{
            setData(res.data)
        }).catch((e)=>{
            console.log(e)
        })
    }
    useEffect(()=>{
        getData()
    },[data])

    const logoutStyle = {
      position: 'absolute',
      top: '15px',
      right: '20px',
      textDecoration: 'none',
      color: 'white',
      fontWeight: 'bold',
  };
    return(
        <>
         <div className="container" style={{marginTop:'50px'}}>
         <Link to="/" style={logoutStyle}>Logout</Link>

     <center><h2>Employee Attendance Data</h2></center> 
      <table className="table table-bordered" style={{marginTop:'50px'}}>
      <thead className='thead-dark' style={{borderRadius:'5px',backgroundColor:'black',color:'white'}}>
          <tr>
            <th>S.No</th>
            <th>Attendance Id</th>
            <th>Employee Id</th>
            <th>Date</th>
            <th>CheckInTime</th>
            <th>CheckOutTime</th>
            {/* Add more columns if needed */}
          </tr>
        </thead>
        <tbody>
          {/* {departments.filter(department => department.Id.toLowerCase().includes(searchTerm.toLowerCase()))} */}
          {
          data.map((e,i) => (
            <tr key={i}>
              <td>{i+1}</td>
              <td>{e.attendanceId}</td>
              <td>{e.employeeId}</td>
              <td>{e.date}</td>
              <td>{e.checkInTime}</td>
              <td>{e.checkOutTime}</td>
            </tr>
          ))  
          }
        </tbody>
      </table>
    </div>
        </>
    )
}
export default Attendance