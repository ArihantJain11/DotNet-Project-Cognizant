import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

const EmployeePage = () => {
  const [employees, setEmployees] = useState([]);

  useEffect(() => {
    fetchEmployees();
  }, []);

  const fetchEmployees = async () => {
    try {
      const response = await axios.get('https://localhost:7211/api/Employee');
      const sortedData = response.data.sort((a,b)=>a.departmentId-b.departmentId);
      //setEmployees(response.data);
      setEmployees(sortedData);

    } catch (error) {
      console.error('Error fetching Employee:', error);
    }
  };
  const logoutStyle = {
    position: 'absolute',
    top: '15px',
    right: '20px',
    textDecoration: 'none',
    color: 'white',
    fontWeight: 'bold',
};
  return (
    <div className="container" style={{marginTop:'50px',backgroundColor:'#dee0e3'}}>
      <Link to="/" style={logoutStyle}>Logout</Link>

     <center> <h2>Employee Details</h2></center>
      <table className="table table-bordered" style={{marginTop:'50px'}}>
        <thead className='thead-dark' style={{borderRadius:'5px',backgroundColor:'black',color:'white'}}>
          <tr>
            <th>Employee ID</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Address</th>
            <th>Join Date</th>
            <th>Department ID</th>
            {/* Add more columns if needed */}
          </tr>
        </thead>
        <tbody>
          {/* {employees.filter(employee => employee.firstname.toLowerCase().includes(searchTerm.toLowerCase()))} */}
          {employees.map(employee => (
            <tr key={employee.employeeId}>
              <td>{employee.employeeId}</td>
              <td>{employee.firstName}</td>
              <td>{employee.lastName}</td>
              <td>{employee.email}</td>
              <td>{employee.phone}</td>
              <td>{employee.address}</td>
              <td>{employee.joinDate}</td>
              <td>{employee.departmentId}</td>
              {/* Add more columns if needed */}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default EmployeePage;