// Footer.js
import React from 'react';

const Footer = () => {
    const footerStyle = {
        left: '0',
        bottom: '0',
        top:'50px',
        width: '100%',
        backgroundColor: '#dee0e3',
        color: 'black',
        textAlign: 'center',
        padding: '10px',
        
    };

    return (
        <div style={footerStyle}>
            <p>© 2024 Management App for Hrs. All rights reserved.</p>
        </div>
    );
};

export default Footer;
