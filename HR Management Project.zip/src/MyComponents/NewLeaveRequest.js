
// LeaveRequestForm.js
import axios from 'axios';
import React, { useState } from 'react';
import { useNavigate,Link,useParams } from 'react-router-dom'; // Import useHistory from React Router

const LeaveRequestForm = () => {
    //console.log(employeeId)
    const { employeeId } = useParams();
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [leaveType, setLeaveType] = useState("");

  const navigate = useNavigate(); // Get the history object

  const handleSubmit = (e) => {
    e.preventDefault();
    // Make your API call here (replace with your actual API endpoint)
    const data={
       
  employeeId: parseInt(employeeId),
  leaveStartDate: startDate,
  leaveEndDate: endDate,
  leaveType: leaveType,
  status: "pending"
    }
    console.log(data)
    axios.post(`https://localhost:7211/api/LeaveRequest`,data).then((res)=>{
        console.log(res.data)
    alert("Leave Request Submitted!!!!")
  
    }).catch((e)=>{
        console.log(e)
    })
    
  };
  const logoutStyle = {
    position: 'absolute',
    top: '15px',
    right: '20px',
    textDecoration: 'none',
    color: 'white',
    fontWeight: 'bold',
};

  return (
    <div className='container mt-5'>
            <Link to="/" style={logoutStyle}>Logout</Link>

    <h2>Leave Request Form</h2>
    <form >
      {/* Start Date */}
      <div className="mb-3">
        <label htmlFor="startDate">Start Date</label>
        <input
          type="date"
          id="startDate"
          className="form-control"
          value={startDate}
          onChange={(e) => setStartDate(e.target.value)}
        />
      </div>
  
      {/* End Date */}
      <div className="mb-3">
        <label htmlFor="endDate">End Date</label>
        <input
          type="date"
          id="endDate"
          className="form-control"
          value={endDate}
          onChange={(e) => setEndDate(e.target.value)}
        />
      </div>
  
      {/* Leave Type */}
      <div className="mb-3">
        <label htmlFor="leaveType">Leave Type</label>
        <select
          id="leaveType"
          className="form-select"
          value={leaveType}
          onChange={(e) => setLeaveType(e.target.value)}
        >
          <option value="">Select Leave Type</option>
          <option value="Vacation">Vacation</option>
          <option value="Sick">Sick Leave</option>
          <option value="Casual">Casual</option>
          <option value="Earned"> Earned</option>
          {/* Add other leave types */}
        </select>
      </div>
  
      {/* Employee ID (passed from the URL parameter) */}
      <input
        type="hidden"
        id="employeeId"
        value={employeeId} // Replace with the actual employee ID
      />
  
      <button type="submit" className="btn btn-dark" onClick={(e)=>handleSubmit(e)}>
        Submit
      </button>
    </form>
  </div>
  
  );
};

export default LeaveRequestForm;