import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
const DepartmentTable = () => {
  const [departments, setDepartments] = useState([]);

  useEffect(() => {
    fetchDepartments();
  }, []);

  const fetchDepartments = async () => {
    try {
      const response = await axios.get('https://localhost:7211/api/department');
      setDepartments(response.data);
    } catch (error) {
      console.error('Error fetching departments:', error);
    }
  };

  const logoutStyle = {
    position: 'absolute',
    top: '15px',
    right: '20px',
    textDecoration: 'none',
    color: 'white',
    fontWeight: 'bold',
};

  return (
    <div className="container" style={{marginTop:'50px'}}>
      <Link to="/" style={logoutStyle}>Logout</Link>

     <center><h2>Departments</h2></center> 
      <table className="table table-bordered" style={{marginTop:'50px'}}>
      <thead className='thead-dark' style={{borderRadius:'5px',backgroundColor:'black',color:'white'}}>
          <tr>
            <th>ID</th>
            <th>Name</th>
            {/* Add more columns if needed */}
          </tr>
        </thead>
        <tbody>
          {/* {departments.filter(department => department.Id.toLowerCase().includes(searchTerm.toLowerCase()))} */}
          {departments.map(department => (
            <tr key={department.departmentId}>
              <td>{department.departmentId}</td>
              <td>{department.departmentName}</td>
              {/* Add more columns if needed */}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default DepartmentTable;