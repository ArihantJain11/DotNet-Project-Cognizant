import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';


const EmployeeProfile = () => {
    const location = useLocation();
    const { employee } = location.state;
    localStorage.setItem("id",employee.employeeId)
    const [salary,setSalary]=useState([])
  const emp = employee.employeeId
  console.log(emp)
    const getSalary = () => {
      try {
        // Replace the URL with the actual API endpoint
        axios.get(`https://localhost:7211/api/Salary`)
          .then((res) => {
            // Assuming the response contains a 'salary' field
            console.log(res.data)
            var flag = 0;
            //const employeeSalary = ""
            for (const entry of res.data) {
              if (entry.employeeId === employee.employeeId) {
                setSalary(entry.netSalary);
                flag++
                break;
              }
            }
            if(!flag){
              setSalary("Not Available")
            }

              
            
            //const employeeSalary = res.data.salary || "Not available";
            
          })
          .catch((error) => {
            console.log(`Error fetching salary for employee ID ${employee.employeeId}: ${error}`);
            setSalary("Not available");
          });
      } catch (e) {
        console.log(`Error fetching salary for employee ID ${employee.employeeId}: ${e}`);
        setSalary("Not available");
      }
    };

useEffect(()=>{
getSalary()
},[])
  if (!employee) {
    // Handle case when employee is not found
    return <div>Employee not found</div>;
  }

  const logoutStyle = {
    position: 'absolute',
    top: '15px',
    right: '20px',
    textDecoration: 'none',
    color: 'white',
    fontWeight: 'bold',
};

  return (
    <div className="container mt-5" style={{width:'600px'}}>
      <Link to="/" style={logoutStyle}>Logout</Link>

      <div className="card" style={{borderRadius:'20px', boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)'}}>
        <div className="card-body">
        <center><h2 className="card-title">Profile</h2></center>
          <div className="row" style={{marginTop:'30px'}}>
            <div className="col-md-6">
              <p><strong>Employee Id:</strong> {employee.employeeId}</p>
              <p><strong>Department ID:</strong> {employee.departmentId}</p>
              <p><strong>First Name:</strong> {employee.firstName}</p>
              <p><strong>Last Name:</strong> {employee.lastName}</p>
              <p><strong>Email:</strong> {employee.email}</p>
              <p><strong>Address:</strong> {employee.address}</p>
              <p><strong>Phone Number:</strong> {employee.phone}</p>
              <p><strong>Join Date:</strong> {employee.joinDate.substring(0,10)}</p>
             <p><strong>Net Salary : </strong>{salary}</p>

              {/* Add other fields as needed */}
            </div>
            <div className="row" style={{ marginTop: '30px' }}>
  <div className="col-md-6">
    {/* Additional profile details (e.g., photo, job title, etc.) */}
    <div className="d-flex justify-content-between">
      <Link to={{pathname:`/pastLeave/${emp.toString()}`}}>
        <button className='btn btn-dark w-45 rounded-0 mb-2 mr-2'>View Past Leave Requests</button>
      </Link>
      <Link to={{pathname:`/newleaverequest/${emp.toString()}`}}>
        <button className='btn btn-dark w-45 rounded-0 mb-2'>Open New Leave Request</button>
      </Link>
    </div>
  </div>
</div>

            
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmployeeProfile;
