import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
const LeaveRequestPage = () => {
  const [LeaveRequest, setLeaveRequest] = useState([]);

  useEffect(() => {
    fetchLeaveRequest();
  }, []);

  const handleA = (e, id) => {
    e.preventDefault();
    axios.get(`https://localhost:7211/api/LeaveRequest/api/LeaveRequest/EditStatusApprove?id=${id}`)
      .then((res) => {
        alert("Leave request approved successfully");
        window.location.reload();
      })
      .catch((e) => {
        console.log(e);
      });
  };

  const handleD = (e, id) => {
    e.preventDefault();
    axios.get(`https://localhost:7211/api/LeaveRequest/api/LeaveRequest/EditStatusDeny?id=${id}`)
      .then((res) => {
        alert("Leave request denied successfully");
        window.location.reload();
      })
      .catch((e) => {
        console.log(e);
      });
  };

  const fetchLeaveRequest = async () => {
    try {
      const response = await axios.get('https://localhost:7211/api/LeaveRequest');
      const sortedData = response.data.sort((a, b) => a.employeeId - b.employeeId);
      setLeaveRequest(sortedData.filter(request => request.status === "pending"));
    } catch (error) {
      console.error('Error fetching LeaveRequest:', error);
    }
  };
  const logoutStyle = {
    position: 'absolute',
    top: '15px',
    right: '20px',
    textDecoration: 'none',
    color: 'white',
    fontWeight: 'bold',
};

  return (
    <div className="container" style={{ marginTop: '50px' }}>
      <Link to="/" style={logoutStyle}>Logout</Link>

      <center><h2>Employee Leave Requests</h2></center>
      <table className="table table-bordered" style={{ marginTop: '50px' }}>
        <thead className='thead-dark' style={{ borderRadius: '5px', color: 'white' }}>
          <tr>
            <th>Employee ID</th>
            <th>LeaveRequest ID</th>
            <th>Leave Start Date</th>
            <th>Leave End Date</th>
            <th>Leave Type</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {LeaveRequest.map((request) => (
            <tr key={request.leaveRequestId}>
              <td>{request.employeeId}</td>
              <td>{request.leaveRequestId}</td>
              <td>{request.leaveStartDate.substring(0, 10)}</td>
              <td>{request.leaveEndDate.substring(0, 10)}</td>
              <td>{request.leaveType}</td>
              
              <td>
                <button type='button' className='btn btn-white ' style={{ border: '1px solid' }} onClick={(e) => handleA(e, request.leaveRequestId)}>Approve</button> &nbsp;
                <button type='button' className='btn btn-dark ' onClick={(e) => handleD(e, request.leaveRequestId)}>Deny</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default LeaveRequestPage;