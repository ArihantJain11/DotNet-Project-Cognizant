// import Header from "./MyComponents/Header";
// import Footer from "./MyComponents/Footer";
// import LandingPage from "./MyComponents/LandingPage";
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import LoginPage from './MyComponents/LoginPage';
import EmployeePage from './MyComponents/EmployeePage';
import MainPage from './MyComponents/MainPage';
import Navbar from './MyComponents/Navbar';
import EmployeeProfile from './MyComponents/EmployeeProfile'
import LeaveRequestPage from './MyComponents/LeaveRequest';
import NewLeaveRequest from './MyComponents/NewLeaveRequest'
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import './MyComponents/style.css';
import DepartmentTable from './MyComponents/DepartmentTable';
import PastLeave from './MyComponents/PastLeave';
import Attendance from './MyComponents/Attendance';
import Salary from './MyComponents/Salary';
import Footer from './MyComponents/Footer';
import Signup from './MyComponents/Signup';
function App() {
  const employees = []; // Populate this with actual data

  return (
   <div style={{backgroundColor:'#dee0e3',minHeight:'100vh'}}>
   <Router>
    
      <Navbar/>
      <Routes>
        <Route path="/" element={<LoginPage/>}/>
        <Route path="/main" element={<MainPage/>}/>
        <Route path="/department" element={<DepartmentTable/>}/>
        <Route path="/employee" element={<EmployeePage/>}/>
        <Route path="/leaverequest" element={<LeaveRequestPage/>}/>
        <Route path="/employee/:email" element={<EmployeeProfile  />} />
        <Route path="/newleaverequest/:employeeId" element={<NewLeaveRequest/>}/>
        <Route path="/PastLeave/:employeeId" element={<PastLeave />} />
        <Route path="/Attendance" element={<Attendance />} />
        <Route path="/Salary" element={<Salary />} />
        <Route path="/signup" element={<Signup/>}/>

      </Routes>
      <Footer/>
     
   </Router>
   </div>
   
  );
}

export default App;




// // App.js
// import React, { useState } from 'react';
// import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
// import LoginPage from './MyComponents/LoginPage';
// import EmployeePage from './MyComponents/EmployeePage';
// import MainPage from './MyComponents/MainPage';
// import Navbar from './MyComponents/Navbar';
// import EmployeeProfile from './MyComponents/EmployeeProfile'
// import LeaveRequestPage from './MyComponents/LeaveRequest';
// import NewLeaveRequest from './MyComponents/NewLeaveRequest'
// import 'bootstrap/dist/css/bootstrap.min.css';
// import './App.css';
// import './MyComponents/style.css';
// import DepartmentTable from './MyComponents/DepartmentTable';
// import PastLeave from './MyComponents/PastLeave';
// import Attendance from './MyComponents/Attendance';
// import Salary from './MyComponents/Salary';

// const App = () => {
//   const [isLoggedIn, setIsLoggedIn] = useState(false);

//   const handleLogin = () => {
//     setIsLoggedIn(true);
//   };

//   const handleLogout = () => {
//     setIsLoggedIn(false);
//   };

//   return (
//     <Router>
//       <Navbar isLoggedIn={isLoggedIn} handleLogout={handleLogout} />
//       <Routes>
//         <Route path="/main" element={<MainPage/>}/>
//         <Route path="/department" element={<DepartmentTable/>}/>
//         <Route path="/employee" element={<EmployeePage/>}/>
//         <Route path="/leaverequest" element={<LeaveRequestPage/>}/>
//         <Route path="/employee/:email" element={<EmployeeProfile  />} />
//         <Route path="/newleaverequest" element={<NewLeaveRequest/>}/>
//         <Route path="/PastLeave/:employeeId" element={<PastLeave />} />
//         <Route path="/Attendance" element={<Attendance />} />
//         <Route path="/Salary" element={<Salary />} />
//         <Route path="/" element={<LoginPage handleLogin={handleLogin} />} />
//       </Routes>
//     </Router>
//   );
// };

// export default App;

